package com.quizPortal.quizPortal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizPortalApplication.class, args);
	}

}
