const CustomLogo = require('./newsiginjpg.jpg')
const SignUpImg = require('./newsiginjpg.jpg')
const CustomBackground = require('./newbgi.jpg')

export{
    CustomLogo,
    SignUpImg,
    CustomBackground
}