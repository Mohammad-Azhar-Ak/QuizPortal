const CustomLogo = require('./tubelight.png')
const SignUpImg = require('./think.png')
const CustomBackground = require('./profile3.jpg')

export{
    CustomLogo,
    SignUpImg,
    CustomBackground
}