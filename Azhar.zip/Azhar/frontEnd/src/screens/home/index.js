import { HomeContainer as Home } from './containers'

export default Home