import QuizPageContainer from './QuizPage'

export {
    QuizPageContainer
}