
   export const token = localStorage.getItem('sessionToken');  


