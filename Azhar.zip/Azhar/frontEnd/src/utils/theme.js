import { createTheme } from '@mui/material/styles';

const myTheme = createTheme({
  palette: {
    primary:{
        main: '#801313'
    },
    secondary:{
        main:  '#801313'
    },
  },
});
export default myTheme