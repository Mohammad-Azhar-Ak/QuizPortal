const CustomLogo = require('./ELearning.jpg')
const SignUpImg = require('./ELearning.jpg')
const CustomBackground = require('./profile30.jpeg')

export{
    CustomLogo,
    SignUpImg,
    CustomBackground
}