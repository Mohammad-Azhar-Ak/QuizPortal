import ProfileContainer from "./Profile";

export{
    ProfileContainer
}