import QuizPageComponent from './QuizPage'
import AnswerDialog from './AnswerDialog'

export {
    QuizPageComponent,
    AnswerDialog
}