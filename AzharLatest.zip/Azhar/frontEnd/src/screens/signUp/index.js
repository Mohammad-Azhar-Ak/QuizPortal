import { SingUpContainer as signUp } from './containers'

export default signUp