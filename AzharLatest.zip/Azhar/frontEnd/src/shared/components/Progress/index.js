import { CircularProgress } from "@mui/material";

const CustomProgress =()=>{
    return (
        <CircularProgress color="primary"/>
    )
}
export default CustomProgress