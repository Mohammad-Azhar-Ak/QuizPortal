const gender = [
    { value: "M", label: "Male" },
    { value: "F", label: "Female" },
    { value: "O", label: "Others" }];

const choice = [
    { value: "true", label: "Yes" },
    { value: "false", label: "No" }

]

export {
    gender,
    choice
}