const base_url="http://localhost:8081";

export default base_url;